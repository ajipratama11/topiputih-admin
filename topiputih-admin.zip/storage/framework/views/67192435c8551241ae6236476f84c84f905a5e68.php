  <!-- Footer -->
  <footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; PT Adikarya Tata Informasi 2022</span>
        </div>
    </div>
</footer>
<!-- End of Footer -->
<?php /**PATH C:\xampp\htdocs\ADITASI\topiputih-admin\resources\views/includes/footer.blade.php ENDPATH**/ ?>